package com;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoTest {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\eclipse-workspace-phase5\\chromedriver_win32\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/index.html");  //load static or dynamic web page
//		String titleTagContent = wd.getTitle();
//		String url = wd.getCurrentUrl();
//		String pageContent = wd.getPageSource();
//		System.out.println(titleTagContent);
//		System.out.println(url);
//		System.out.println(pageContent);
//		
		WebElement h1TagRef = wd.findElement(By.tagName("h1"));
		WebElement pTagRef = wd.findElement(By.tagName("p"));
		WebElement divTagRef = wd.findElement(By.tagName("div"));
		System.out.println(h1TagRef.getTagName()+" = "+h1TagRef.getText());
		System.out.println(pTagRef.getTagName()+" = "+pTagRef.getText());
		System.out.println(divTagRef.getTagName()+" = "+divTagRef.getText());
		List<WebElement> listOfTag = wd.findElements(By.tagName("p"));
		Iterator<WebElement> i1 = listOfTag.iterator();
		while(i1.hasNext()) {
			WebElement ww = i1.next();
			System.out.println(ww.getTagName()+ " "+ww.getText());
		}
		WebElement divTagUsingIdRef = wd.findElement(By.tagName("p"));
		System.out.println(divTagUsingIdRef.getTagName()+ " "+ divTagUsingIdRef.getText());
		wd.close();
	}

}
