package dsa;

public class RangeQueries {
	public static int range(int[] arr, int n , int start, int end) {
		int sum = 0;
		for(int i =start;i<=end;i++) {
			sum += arr[i];
		}
		return sum;
	}

	public static void main(String[] args) {
		int[] arr = {10,20,30,40,50,60,70,80};
		int n = arr.length;
		int start = 1;
		int end = 4;
		System.out.println(range(arr, n, start, end));

	}

}
