package dsa;

import java.util.*;


public class OrderStats{
	public static void main(String[] args) {
		int[] arr = {4,5,15,78,85,23};
		int k = 4; 
		// k is the number for  find the smallest number at kth position
		
		Arrays.sort(arr);
		System.out.println(arr[k-1]);
		
	}
}
