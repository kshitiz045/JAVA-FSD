package com;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ecommerce
 {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\eclipse-workspace-phase5\\chromedriver_win32\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://127.0.0.1:5500/index.html");  //load static or dynamic web page
		//Locating 'browse' button
 WebElement browse =driver.findElement(By.id("uploadfile"));
 //pass the path of the file to be uploaded using Sendkeys method
 browse.sendKeys("D:\\SoftwareTestingMaterial\\UploadFile.txt");

	}

}
